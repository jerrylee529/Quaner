# coding=utf8

__author__ = 'Administrator'

dataPath = 'C:/Stock/Data'
minPath = 'C:/Stock/Min'
configPath =  'C:/Stock'
resultPath = 'C:/Stock/product'

data_dayPath = 'C:/Stock/history_data/day'
# 获取股票代码
instrument_file_path = configPath + '/instruments.txt'

code_list_file = configPath + '/instruments.csv'